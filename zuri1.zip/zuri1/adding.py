# Adding Integers

number1 = 26
number2 = 13

result = number1 + number2

print(result)